# Sentiment-analysis-on-twitter-data-using-MapReduce

For better Understanding please go through :
https://medium.com/@ujala2yz/sentiment-analysis-on-twitter-data-using-apache-hive-and-mapreduce-2d128ec68fa9
